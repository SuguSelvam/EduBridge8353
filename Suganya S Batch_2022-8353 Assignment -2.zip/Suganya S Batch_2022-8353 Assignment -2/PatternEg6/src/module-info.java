/**
 * 
 */
/**
 * @author MAGESH
 *
 */
module PatternEg6 {
}