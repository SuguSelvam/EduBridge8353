package com;

public class Main {

	public static void main(String[] args) {
		
		for(int i=3;i>0;i--) { //rows
			
			for(int k=3;k>i;k--) { //spaces
				
				System.out.print(" ");
			}
			
            for(int j=i;j>=1;j--) { //firsthalf
				
				System.out.print(j);
			}
			
			for(int s=2;s<=i;s++) {//secondhalf
				
				System.out.print(s);
			}
			
			
			System.out.println(" ");
		}

	}

}
