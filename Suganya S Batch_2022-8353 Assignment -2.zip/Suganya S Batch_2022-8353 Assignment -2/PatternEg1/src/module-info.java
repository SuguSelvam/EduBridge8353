/**
 * 
 */
/**
 * @author MAGESH
 *
 */
module PatternEg1 {
}