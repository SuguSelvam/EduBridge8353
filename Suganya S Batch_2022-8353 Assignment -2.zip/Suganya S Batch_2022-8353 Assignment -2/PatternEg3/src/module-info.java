/**
 * 
 */
/**
 * @author MAGESH
 *
 */
module PatternEg3 {
}