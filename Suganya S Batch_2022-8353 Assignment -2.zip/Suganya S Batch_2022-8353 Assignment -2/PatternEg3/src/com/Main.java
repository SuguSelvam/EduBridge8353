package com;

public class Main {

	public static void main(String[] args) {
		
        for(int i=3;i>0;i--) { //rows
        	
        	for(int space=2;space>=i;space--) { //spaces
        		
        		System.out.print(" ");
        	}
        	for(int k=1;k<=i;k++) {//firsthalf
        		
        		System.out.print(k);
        	}
        	
        	for(int j=i-1;j>=1;j--) {//secondhalf
        		
        		System.out.print(j);
        	}
        	System.out.println();

	}

}
}
