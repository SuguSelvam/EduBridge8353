/**
 * 
 */
/**
 * @author MAGESH
 *
 */
module PatternEg4 {
}