package com;

public class Main {

	public static void main(String[] args) {
		
		int i,j,k;
		
		for(i=1;i<=3;i++) {//row
			
			for(j=i;j<3;j++) {//column
				
				System.out.print(" ");
			}
			
			for(k=1;k<(i*2);k++) {//star
				
				System.out.print("*");
			}
			
			System.out.println();
			
		    }
		
	   for(i=2;i>=1;i--) {//row
			
			for(j=3;j>i;j--) {//column
				
				System.out.print(" ");
			}
				
				for(k=1;k<(i*2);k++) {//star
					
					System.out.print("*");
				}
				
				System.out.println();
			}
		
				
				
		}

	}


