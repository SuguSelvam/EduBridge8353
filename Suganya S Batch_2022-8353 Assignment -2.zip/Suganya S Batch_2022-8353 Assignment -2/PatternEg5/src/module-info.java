/**
 * 
 */
/**
 * @author MAGESH
 *
 */
module PatternEg5 {
}