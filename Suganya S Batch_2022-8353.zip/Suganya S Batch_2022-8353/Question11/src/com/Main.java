package com;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
    
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the character :");
        
        char ch = sc.nextLine().charAt(0);
        
        int ascii = (int)ch;
        
        System.out.println(ascii);
        
        if ((ascii>=65) && (ascii<=90))
        {
            System.out.println("Capital letter");
        }
        
        else if ((ascii>=97) && (ascii<=122))
        {
            System.out.println("Small letter");
        }
        
        else if ((ascii>=48 )&& (ascii<=57))
        {
            System.out.println("Digit");
        }
        
        else if((ascii >=0)&& (ascii<=127))
        {
            System.out.println("Special character");
        }
        else {
            
        	System.out.println("character  is : "+ascii);
        
    }
 }
}

