package com;

import java.util.Scanner;

public class GrossSalary {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Salary :");
		
		float basicsalary = sc.nextFloat();
		
		float hra,da;
		
		if(basicsalary<1500 && basicsalary >=0) {
			
			hra = 10 * basicsalary;
			
			hra = hra/100;
			
			da = 90 * basicsalary;
			
			da = da/100;
			
			float GrossSalary = basicsalary+hra+da;
			
			System.out.println("Your gross salary is :" + GrossSalary);
		}
		
		else if(basicsalary>=1500) {
			
			hra = 500;
			
			da = 98 * basicsalary;
			
			da = da/100;
			
			float GrossSalary = basicsalary+hra+da;
			
			System.out.println("Your gross salary is :" + GrossSalary);
					
			
		}
		 
		else {
			 
			 System.out.println("basic salary cant be negative");
		 }
		
	

	}

}
