package com;

import java.util.Scanner;

public class Discount {

	public static void main(String args[]) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the Quantity Purchased :");
		
		int quantity = scanner.nextInt();
		
		System.out.println("Enter the amount price per item :");
		
		float amount = scanner.nextFloat();
		
		float expenses = (quantity*amount);
		
		if(expenses>5000) {
			
			
			
			float discount = 10 * expenses;
			
			discount = discount/100;
			
			expenses = expenses - discount;
			
			
		}
		
		else {
			
			expenses = (quantity*amount);
			
		}
		
		System.out.println("Total expenses is :" + expenses);
		
		
	
 
	}
}

