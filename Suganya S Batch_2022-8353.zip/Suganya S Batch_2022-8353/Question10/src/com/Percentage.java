package com;

import java.util.Scanner;

public class Percentage {

	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter The Five Subject Marks :");
		
		int maths = input.nextInt();
		
		int science = input.nextInt();
		
		int social = input.nextInt();
		
		int gk = input.nextInt();
		
		int hindi = input.nextInt();
		
		int tot = maths+science+social+gk+hindi;
		
		float per = tot/5;
		
		System.out.println("Total :"+tot);
		
		System.out.println("Percentage :"+per);	
		
		if(per>=60)
		{			
			System.out.println("First Division.");
		}
		
		else if(per>=50 && per<=59)
		{			
			System.out.println("Second Division.");
		}
		
		else if(per>=40 && per<=49)
		{			
			System.out.println("Third  Division.");
		}
		
		else
		{			
			System.out.println("Fail");
		}
		
	}
}
