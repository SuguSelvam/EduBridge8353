/**
 * 
 */
/**
 * @author MAGESH
 *
 */
module Question1 {
}