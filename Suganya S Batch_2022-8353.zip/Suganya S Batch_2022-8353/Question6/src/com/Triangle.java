package com;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the 1st angle of triangle :");
		
		int angle1 = scanner.nextInt();
		
        System.out.println("Enter the 2nd  angle of triangle :");
		
		int angle2 = scanner.nextInt();
		
        System.out.println("Enter the 3rd  angle of triangle :");
		
		int angle3 = scanner.nextInt();
		
		if(angle1+angle2+angle3 == 180) {
			
			System.out.println(" A triangle is valid ");
			
		}
		
		else {
			
			System.out.println(" A triangle is invalid ");
		}
		

	}

}
