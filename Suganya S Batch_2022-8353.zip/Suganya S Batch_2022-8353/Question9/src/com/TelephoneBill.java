package com;

import java.util.Scanner;

public class TelephoneBill {
	
	   public static void main(String args[]) {
	
		     Scanner sc = new Scanner(System.in);
 
	         System.out.println("enter the no of calls :");
	
	         double calls,totalbill=0;
 
	         calls = sc.nextDouble();
	         
	         if(calls>=0 && calls<=100) {
	 		
	 			totalbill = 200;
	 		}

 
	        else if(calls>100 &&calls<=150) {
	        	 
	        	calls = calls-100;
	        	 
	 			totalbill = 200+(calls*0.60);
	 		}
	  
	        else if(calls>150 && calls<=200) {
	        	
	        	calls = calls-150;
	        	
				totalbill = 200+(50*0.60)+(calls*0.50);

	              
	        }
	  
	        else if(calls>200) {
	
	        	calls = calls-200;
	        	 
	 			totalbill = 200+(50*0.60)+(50*0.50)+(calls*0.40);

	         }
	         
	         else {
	 		
	 		   totalbill = 0;
	 			   
	 		   System.out.println("Invalid input");
	 		   
	 		}

 
	        System.out.println("The total bill is Rs: " +totalbill );
	 
	}
}


