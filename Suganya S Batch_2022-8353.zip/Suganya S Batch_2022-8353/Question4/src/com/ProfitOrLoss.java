package com;

import java.util.Scanner;

public class ProfitOrLoss {
	
	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter The Cost Price :");
		
		int costprice = input.nextInt();
		
		System.out.println("Enter The Selling Price :");
		
		int sellingprice = input.nextInt();
		
		int profit,loss;	
		
		if(sellingprice>costprice)
		{
			profit = sellingprice - costprice;
			
			System.out.println("Profit is  : "+profit);
		}
		
		else if(sellingprice<costprice)
		{
			loss = costprice - sellingprice;
			
			System.out.println("Loss is : "+loss);	
		}
		
		else
		{
			
			System.out.println("No Profit No Loss");
		}
	}
}


