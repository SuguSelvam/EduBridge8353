package com;

import java.util.Scanner;

public class YoungestAge {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the age of ram :");
		
		int age1 = scanner.nextInt();
		
        System.out.println("Enter the age of Sublabh :");
		
		int age2 = scanner.nextInt();
		
        System.out.println("Enter the age of ajay :");
		
		int age3 = scanner.nextInt();
		
		if((age1<age2)&&(age1<age3)) {
		
		    System.out.println("Ram is the youngest of three");
		
		}
		
		else if((age2<age1)&&(age2<age3)) {
			
			System.out.println("Sulabh is the youngest of three");
			
		}
		
		else {
			
			System.out.println("Ajay is the youngest of three");
			
		}
		
		
		

	}

}

